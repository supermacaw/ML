import scipy.io, numpy as np, sklearn.svm
from sklearn.metrics import confusion_matrix
from matplotlib import pyplot as plt 

train_data=scipy.io.loadmat('./data/digit-dataset/train.mat')
images=train_data['train_images']
labels = train_data['train_labels']

def train_and_cross_validate(k, CValue):

	#shuffle
	total = 0 #use to calculate mean of the accuracies
	shuffle_numbers = np.random.choice(60000, 10000, replace=False)
	reshaped_shuffled = np.reshape(np.rollaxis(images[:,:,shuffle_numbers],2,0),(10000,784))
	shuffled_labels = labels[shuffle_numbers]
	
	#k folds
	folds = [] 
	folds_labels = []
	fold_size = 10000/k
	for i in range(k):
		folds.append(reshaped_shuffled[fold_size*i : (fold_size)*(i+1),:])
		folds_labels.append(shuffled_labels[fold_size*i : fold_size * (i+1),:])

	for exclude in range(k):
		training_set = np.zeros(((k-1)*fold_size, 784))
		training_labels = np.zeros(((k-1)*fold_size,))
		#print training_set.shape, training_labels.shape
		to_use = range(k)
		to_use.remove(exclude)
		#print to_use
		for i in range(k-1):
			training_set[fold_size * i: fold_size * (i+1) , :] = folds[to_use[i]]
			training_labels[fold_size * i : fold_size * (i+1)] = folds_labels[to_use[i]].ravel()
		clf = sklearn.svm.SVC(C=CValue,kernel='poly',degree=2)
		clf.fit(training_set, training_labels ) 
		predictions = clf.predict(folds[exclude])
		truth = folds_labels[exclude]

		count = 0
		for i in range(fold_size):
    			if predictions[i]==truth[i]:
               			count +=1
		"""cm = confusion_matrix(truth, predictions)
		plt.matshow(cm)
		plt.title('Confusion matrix')
		plt.colorbar()
		plt.ylabel('True label')
		plt.xlabel('Predicted label')
		plt.show()"""
		#print float(count)/float(fold_size)	
		total += float(count)/float(fold_size)
	print total/float(10)
	return total/float(10)

accuracy = []
CValues = [10e-9, 10e-8, 10e-7, 10e-6, 10e-5, 10e-4, 10e-3, 10e-2, 0.1, 10, 100, 1000, 10000, 100000]
for c in CValues:
    accuracy.append(train_and_cross_validate(10, c))
print accuracy
#plt.plot(train_sizes,accuracy)
#plt.show()

